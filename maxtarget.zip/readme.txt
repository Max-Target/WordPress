=== inTarget eCommerce ===
Contributors: MaxTarget Team
Tags: монетизация
Requires at least: 3.0.1
Tested up to: 4.5.2
Stable tag: 1.0.0

MaxTarget — система монетизации.

== Description ==
MaxTarget — система монетизации.

== Installation ==
1. Выберите Плагины -> Добавить новый.
2. В строке поиска введите MaxTarget.
3. Установите плагин *MaxTarget* и активируйте его.
4. Введите Еmail и полученный на сайте http://maxtarget.ru Ключ API.

== Screenshots ==
1. Плагин MaxTarget
2. Личный кабинет на сайте http://maxtarget.ru

== Changelog ==

= 1.0.0 =
* Первая версия плагина